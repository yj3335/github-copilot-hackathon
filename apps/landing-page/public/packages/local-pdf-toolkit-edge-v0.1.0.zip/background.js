// src/background.ts
chrome.runtime.onInstalled.addListener(() => {
  console.info("Local PDF Toolkit installed.");
});
//# sourceMappingURL=background.js.map
